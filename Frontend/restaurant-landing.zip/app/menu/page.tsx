"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Download, FileText, ImageIcon } from "lucide-react"
import Link from "next/link"
import { Header } from "../../components/header"
import { MenuItemCard } from "../../components/menu-item-card"
import { useRestaurant } from "../../contexts/restaurant-context"

export default function MenuPage() {
  const { state } = useRestaurant()

  // Group products by category
  const productsByCategory = state.products.reduce(
    (acc, product) => {
      if (!acc[product.category]) {
        acc[product.category] = []
      }
      acc[product.category].push(product)
      return acc
    },
    {} as Record<string, typeof state.products>,
  )

  const categories = Object.keys(productsByCategory).sort()

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <Link href="/" className="flex items-center space-x-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="h-5 w-5" />
                <span className="font-medium">Back to Home</span>
              </Link>
              <h1 className="text-3xl font-bold">Our Menu</h1>
              <div></div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          {/* Check if admin has uploaded a menu file */}
          {state.menuFile.url ? (
            <div className="max-w-4xl mx-auto">
              <Card>
                <CardHeader className="text-center">
                  <CardTitle className="flex items-center justify-center space-x-2">
                    {state.menuFile.type === "pdf" ? (
                      <FileText className="h-6 w-6 text-red-600" />
                    ) : (
                      <ImageIcon className="h-6 w-6 text-blue-600" />
                    )}
                    <span>Restaurant Menu</span>
                  </CardTitle>
                  <p className="text-gray-600">
                    Uploaded on {new Date(state.menuFile.uploadedAt!).toLocaleDateString()}
                  </p>
                </CardHeader>
                <CardContent>
                  {state.menuFile.type === "pdf" ? (
                    <div className="space-y-4">
                      <div className="bg-gray-100 rounded-lg p-8 text-center">
                        <FileText className="h-16 w-16 text-red-600 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold mb-2">{state.menuFile.name}</h3>
                        <p className="text-gray-600 mb-4">Click the button below to view our complete menu</p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                          <Button asChild className="bg-red-600 hover:bg-red-700">
                            <a href={state.menuFile.url} target="_blank" rel="noopener noreferrer">
                              <FileText className="h-4 w-4 mr-2" />
                              View PDF Menu
                            </a>
                          </Button>
                          <Button variant="outline" asChild>
                            <a href={state.menuFile.url} download={state.menuFile.name}>
                              <Download className="h-4 w-4 mr-2" />
                              Download Menu
                            </a>
                          </Button>
                        </div>
                      </div>

                      {/* Embedded PDF viewer */}
                      <div className="w-full h-[800px] border rounded-lg overflow-hidden">
                        <iframe src={state.menuFile.url} className="w-full h-full" title="Restaurant Menu PDF" />
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <img
                        src={state.menuFile.url || "/placeholder.svg"}
                        alt="Restaurant Menu"
                        className="max-w-full h-auto mx-auto rounded-lg shadow-lg"
                        style={{ maxHeight: "1000px" }}
                      />
                      <div className="mt-4">
                        <Button variant="outline" asChild>
                          <a href={state.menuFile.url} download={state.menuFile.name}>
                            <Download className="h-4 w-4 mr-2" />
                            Download Menu
                          </a>
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Display menu items if no file is uploaded */
            <div>
              <div className="text-center mb-12">
                <h2 className="text-2xl font-bold mb-4">Explore Our Delicious Menu</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Discover our authentic Italian dishes, crafted with the finest ingredients and traditional recipes
                  passed down through generations.
                </p>
              </div>

              {categories.length > 0 ? (
                <div className="space-y-12">
                  {categories.map((category) => (
                    <div key={category}>
                      <h3 className="text-2xl font-bold mb-6 text-center text-orange-600">{category}</h3>
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {productsByCategory[category].map((product) => (
                          <MenuItemCard
                            key={product.id}
                            id={product.id}
                            name={product.name}
                            price={product.price}
                            description={product.description}
                            image={product.image}
                            badge={!product.available ? "Unavailable" : undefined}
                            badgeColor={!product.available ? "bg-red-600" : "bg-green-600"}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="text-gray-400 text-6xl mb-4">🍽️</div>
                  <h3 className="text-2xl font-semibold mb-4">Menu Coming Soon</h3>
                  <p className="text-gray-500 mb-8">
                    We're working on updating our menu. Please check back later or contact us for current offerings.
                  </p>
                  <Link href="/contact">
                    <Button className="bg-orange-600 hover:bg-orange-700">Contact Us</Button>
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
