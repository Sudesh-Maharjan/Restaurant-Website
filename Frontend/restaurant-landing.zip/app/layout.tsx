import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { CartProvider } from "../contexts/cart-context"
import { RestaurantProvider } from "../contexts/restaurant-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Bella Vista - Authentic Italian Restaurant",
  description: "Experience authentic Italian cuisine in the heart of the city",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <RestaurantProvider>
          <CartProvider>{children}</CartProvider>
        </RestaurantProvider>
      </body>
    </html>
  )
}
