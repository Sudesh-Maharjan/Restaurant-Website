"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Upload, FileText, ImageIcon, Trash2, Eye, ExternalLink } from "lucide-react"
import Image from "next/image"
import { useRestaurant } from "../../../contexts/restaurant-context"
import Link from "next/link"

export default function AdminSettings() {
  const { state, dispatch } = useRestaurant()
  const [restaurantInfo, setRestaurantInfo] = useState({
    name: "Bella Vista",
    tagline: "Authentic Italian Dining Experience",
    description:
      "For over 30 years, Bella Vista has been serving authentic Italian cuisine in the heart of the city. Our family recipes, passed down through generations, bring the true taste of Italy to your table.",
    logo: "/placeholder.svg?height=200&width=200",
    phone: "(555) 123-4567",
    email: "info@bellavista.com",
    address: "123 Italian Street, Downtown District, New York, NY 10001",
    hours: {
      monday: "11:30 AM - 10:00 PM",
      tuesday: "11:30 AM - 10:00 PM",
      wednesday: "11:30 AM - 10:00 PM",
      thursday: "11:30 AM - 10:00 PM",
      friday: "11:30 AM - 11:00 PM",
      saturday: "11:30 AM - 11:00 PM",
      sunday: "12:00 PM - 9:00 PM",
    },
  })

  const [settings, setSettings] = useState({
    onlineOrdering: true,
    reservations: true,
    deliveryRadius: 5,
    minimumOrder: 15,
    deliveryFee: 3.99,
    taxRate: 8.875,
    autoAcceptOrders: false,
    sendOrderConfirmations: true,
    allowReviews: true,
    showPricesOnMenu: true,
  })

  const handleInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setRestaurantInfo({
      ...restaurantInfo,
      [name]: value,
    })
  }

  const handleHoursChange = (day: string, value: string) => {
    setRestaurantInfo({
      ...restaurantInfo,
      hours: {
        ...restaurantInfo.hours,
        [day]: value,
      },
    })
  }

  const handleSettingChange = (name: string, value: any) => {
    setSettings({
      ...settings,
      [name]: value,
    })
  }

  const handleMenuUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      alert("File size must be less than 10MB")
      return
    }

    // Check file type
    const allowedTypes = ["application/pdf", "image/jpeg", "image/jpg", "image/png", "image/gif"]
    if (!allowedTypes.includes(file.type)) {
      alert("Please upload a PDF or image file (JPG, PNG, GIF)")
      return
    }

    // Create object URL for preview (in a real app, you'd upload to a server)
    const url = URL.createObjectURL(file)
    const type = file.type === "application/pdf" ? "pdf" : "image"

    dispatch({
      type: "UPLOAD_MENU",
      payload: {
        type,
        url,
        name: file.name,
      },
    })

    // Reset input
    e.target.value = ""
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Restaurant Settings</h1>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid grid-cols-4 w-full max-w-lg">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="hours">Hours</TabsTrigger>
          <TabsTrigger value="menu">Menu</TabsTrigger>
          <TabsTrigger value="ordering">Ordering</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Restaurant Information</CardTitle>
                <CardDescription>Basic information about your restaurant</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row gap-8">
                  <div className="md:w-1/3 flex flex-col items-center">
                    <div className="relative h-40 w-40 rounded-full overflow-hidden border-4 border-gray-200">
                      <Image
                        src={restaurantInfo.logo || "/placeholder.svg"}
                        alt="Restaurant logo"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <Button variant="outline" className="mt-4">
                      <Upload className="h-4 w-4 mr-2" />
                      Change Logo
                    </Button>
                  </div>

                  <div className="md:w-2/3 space-y-4">
                    <div>
                      <Label htmlFor="name">Restaurant Name</Label>
                      <Input id="name" name="name" value={restaurantInfo.name} onChange={handleInfoChange} />
                    </div>

                    <div>
                      <Label htmlFor="tagline">Tagline</Label>
                      <Input id="tagline" name="tagline" value={restaurantInfo.tagline} onChange={handleInfoChange} />
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        name="description"
                        value={restaurantInfo.description}
                        onChange={handleInfoChange}
                        rows={4}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>How customers can reach your restaurant</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" name="phone" value={restaurantInfo.phone} onChange={handleInfoChange} />
                </div>

                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={restaurantInfo.email}
                    onChange={handleInfoChange}
                  />
                </div>

                <div>
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    name="address"
                    value={restaurantInfo.address}
                    onChange={handleInfoChange}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="hours">
          <Card>
            <CardHeader>
              <CardTitle>Business Hours</CardTitle>
              <CardDescription>Set your restaurant's operating hours</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(restaurantInfo.hours).map(([day, hours]) => (
                <div key={day} className="grid grid-cols-3 items-center gap-4">
                  <Label htmlFor={day} className="capitalize">
                    {day}
                  </Label>
                  <Input
                    id={day}
                    value={hours}
                    onChange={(e) => handleHoursChange(day, e.target.value)}
                    className="col-span-2"
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="menu">
          <Card>
            <CardHeader>
              <CardTitle>Menu Management</CardTitle>
              <CardDescription>Upload your restaurant's menu as PDF or image</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {state.menuFile.url ? (
                <div className="border rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      {state.menuFile.type === "pdf" ? (
                        <FileText className="h-8 w-8 text-red-600" />
                      ) : (
                        <ImageIcon className="h-8 w-8 text-blue-600" />
                      )}
                      <div>
                        <h3 className="font-semibold">{state.menuFile.name}</h3>
                        <p className="text-sm text-gray-500">
                          Uploaded on {new Date(state.menuFile.uploadedAt!).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => dispatch({ type: "REMOVE_MENU" })}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove
                    </Button>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" asChild>
                      <a href={state.menuFile.url} target="_blank" rel="noopener noreferrer">
                        <Eye className="h-4 w-4 mr-2" />
                        Preview
                      </a>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link href="/menu">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View on Site
                      </Link>
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Upload Menu</h3>
                  <p className="text-gray-500 mb-4">Upload a PDF or image file of your restaurant menu</p>
                  <div className="space-y-2">
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png,.gif"
                      onChange={handleMenuUpload}
                      className="hidden"
                      id="menu-upload"
                    />
                    <Button asChild className="bg-orange-600 hover:bg-orange-700">
                      <label htmlFor="menu-upload" className="cursor-pointer">
                        <Upload className="h-4 w-4 mr-2" />
                        Choose File
                      </label>
                    </Button>
                    <p className="text-xs text-gray-400">Supported formats: PDF, JPG, PNG, GIF (Max 10MB)</p>
                  </div>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <div className="text-blue-600 mt-0.5">ℹ️</div>
                  <div>
                    <h4 className="font-semibold text-blue-900">How it works</h4>
                    <ul className="text-sm text-blue-800 mt-2 space-y-1">
                      <li>• Upload a PDF or image of your menu</li>
                      <li>• Customers will see this when they click "View Full Menu"</li>
                      <li>• If no menu is uploaded, individual menu items will be displayed</li>
                      <li>• You can update or remove the menu anytime</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ordering">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Ordering Settings</CardTitle>
                <CardDescription>Configure how customers can order from your restaurant</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Online Ordering</h3>
                    <p className="text-sm text-gray-500">Allow customers to order online</p>
                  </div>
                  <Switch
                    checked={settings.onlineOrdering}
                    onCheckedChange={(checked) => handleSettingChange("onlineOrdering", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Reservations</h3>
                    <p className="text-sm text-gray-500">Allow customers to make table reservations</p>
                  </div>
                  <Switch
                    checked={settings.reservations}
                    onCheckedChange={(checked) => handleSettingChange("reservations", checked)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="deliveryRadius">Delivery Radius (miles)</Label>
                    <Input
                      id="deliveryRadius"
                      type="number"
                      value={settings.deliveryRadius}
                      onChange={(e) => handleSettingChange("deliveryRadius", Number.parseFloat(e.target.value))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="minimumOrder">Minimum Order ($)</Label>
                    <Input
                      id="minimumOrder"
                      type="number"
                      value={settings.minimumOrder}
                      onChange={(e) => handleSettingChange("minimumOrder", Number.parseFloat(e.target.value))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="deliveryFee">Delivery Fee ($)</Label>
                    <Input
                      id="deliveryFee"
                      type="number"
                      value={settings.deliveryFee}
                      onChange={(e) => handleSettingChange("deliveryFee", Number.parseFloat(e.target.value))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="taxRate">Tax Rate (%)</Label>
                    <Input
                      id="taxRate"
                      type="number"
                      value={settings.taxRate}
                      onChange={(e) => handleSettingChange("taxRate", Number.parseFloat(e.target.value))}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Additional Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Auto-Accept Orders</h3>
                    <p className="text-sm text-gray-500">Automatically accept incoming orders</p>
                  </div>
                  <Switch
                    checked={settings.autoAcceptOrders}
                    onCheckedChange={(checked) => handleSettingChange("autoAcceptOrders", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Order Confirmations</h3>
                    <p className="text-sm text-gray-500">Send email confirmations for orders</p>
                  </div>
                  <Switch
                    checked={settings.sendOrderConfirmations}
                    onCheckedChange={(checked) => handleSettingChange("sendOrderConfirmations", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Customer Reviews</h3>
                    <p className="text-sm text-gray-500">Allow customers to leave reviews</p>
                  </div>
                  <Switch
                    checked={settings.allowReviews}
                    onCheckedChange={(checked) => handleSettingChange("allowReviews", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Show Prices on Menu</h3>
                    <p className="text-sm text-gray-500">Display prices on the public menu</p>
                  </div>
                  <Switch
                    checked={settings.showPricesOnMenu}
                    onCheckedChange={(checked) => handleSettingChange("showPricesOnMenu", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-8 flex justify-end">
        <Button className="bg-orange-600 hover:bg-orange-700">Save All Settings</Button>
      </div>
    </div>
  )
}
