"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Eye, Mail, Phone, Calendar, DollarSign } from "lucide-react"
import { useRestaurant, type Customer } from "../../../contexts/restaurant-context"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function AdminCustomers() {
  const { state } = useRestaurant()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)

  const filteredCustomers = state.customers.filter((customer) => {
    const searchLower = searchTerm.toLowerCase()
    return (
      customer.firstName.toLowerCase().includes(searchLower) ||
      customer.lastName.toLowerCase().includes(searchLower) ||
      customer.email.toLowerCase().includes(searchLower) ||
      customer.phone.toLowerCase().includes(searchLower)
    )
  })

  const getCustomerOrders = (customerId: string) => {
    return state.orders.filter((order) => order.customerId === customerId)
  }

  const getCustomerTier = (totalSpent: number) => {
    if (totalSpent >= 500) return { tier: "Gold", color: "bg-yellow-100 text-yellow-800" }
    if (totalSpent >= 200) return { tier: "Silver", color: "bg-gray-100 text-gray-800" }
    return { tier: "Bronze", color: "bg-orange-100 text-orange-800" }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Customers</h1>
        <div className="text-sm text-gray-500">Total Customers: {state.customers.length}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Customers</p>
                <p className="text-2xl font-bold">{state.customers.length}</p>
              </div>
              <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-bold">👥</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Gold Members</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {state.customers.filter((c) => c.totalSpent >= 500).length}
                </p>
              </div>
              <div className="h-8 w-8 bg-yellow-100 rounded-full flex items-center justify-center">
                <span className="text-yellow-600 font-bold">⭐</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg. Order Value</p>
                <p className="text-2xl font-bold text-green-600">
                  $
                  {state.customers.length > 0
                    ? (
                        state.customers.reduce((sum, c) => sum + c.totalSpent, 0) /
                        state.customers.reduce((sum, c) => sum + c.totalOrders, 0)
                      ).toFixed(2)
                    : "0.00"}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">New This Month</p>
                <p className="text-2xl font-bold text-purple-600">
                  {
                    state.customers.filter((c) => {
                      const joinDate = new Date(c.joinedDate)
                      const now = new Date()
                      return joinDate.getMonth() === now.getMonth() && joinDate.getFullYear() === now.getFullYear()
                    }).length
                  }
                </p>
              </div>
              <Calendar className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search customers by name, email, or phone..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Customers ({filteredCustomers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Tier</TableHead>
                <TableHead>Orders</TableHead>
                <TableHead>Total Spent</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Last Order</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => {
                const customerTier = getCustomerTier(customer.totalSpent)
                return (
                  <TableRow key={customer.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {customer.firstName} {customer.lastName}
                        </div>
                        <div className="text-sm text-gray-500">ID: {customer.id}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center text-sm">
                          <Mail className="h-3 w-3 mr-1" />
                          {customer.email}
                        </div>
                        <div className="flex items-center text-sm">
                          <Phone className="h-3 w-3 mr-1" />
                          {customer.phone}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={customerTier.color}>{customerTier.tier}</Badge>
                    </TableCell>
                    <TableCell className="font-medium">{customer.totalOrders}</TableCell>
                    <TableCell className="font-medium text-green-600">${customer.totalSpent.toFixed(2)}</TableCell>
                    <TableCell>{new Date(customer.joinedDate).toLocaleDateString()}</TableCell>
                    <TableCell>{new Date(customer.lastOrderDate).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" onClick={() => setSelectedCustomer(customer)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[600px]">
                          <DialogHeader>
                            <DialogTitle>
                              Customer Details - {customer.firstName} {customer.lastName}
                            </DialogTitle>
                            <DialogDescription>
                              Customer since {new Date(customer.joinedDate).toLocaleDateString()}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <h4 className="font-semibold mb-2">Contact Information</h4>
                                <p>
                                  <strong>Name:</strong> {customer.firstName} {customer.lastName}
                                </p>
                                <p>
                                  <strong>Email:</strong> {customer.email}
                                </p>
                                <p>
                                  <strong>Phone:</strong> {customer.phone}
                                </p>
                              </div>
                              <div>
                                <h4 className="font-semibold mb-2">Customer Stats</h4>
                                <p>
                                  <strong>Total Orders:</strong> {customer.totalOrders}
                                </p>
                                <p>
                                  <strong>Total Spent:</strong> ${customer.totalSpent.toFixed(2)}
                                </p>
                                <p>
                                  <strong>Avg Order:</strong> ${(customer.totalSpent / customer.totalOrders).toFixed(2)}
                                </p>
                                <p>
                                  <strong>Tier:</strong>{" "}
                                  <Badge className={getCustomerTier(customer.totalSpent).color}>
                                    {getCustomerTier(customer.totalSpent).tier}
                                  </Badge>
                                </p>
                              </div>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2">Recent Orders</h4>
                              <div className="space-y-2 max-h-64 overflow-y-auto">
                                {getCustomerOrders(customer.id)
                                  .slice(0, 5)
                                  .map((order) => (
                                    <div
                                      key={order.id}
                                      className="flex items-center justify-between p-2 border rounded"
                                    >
                                      <div>
                                        <p className="font-medium">{order.id}</p>
                                        <p className="text-sm text-gray-500">
                                          {new Date(order.createdAt).toLocaleDateString()} - {order.items.length} items
                                        </p>
                                      </div>
                                      <div className="text-right">
                                        <p className="font-medium">${order.total.toFixed(2)}</p>
                                        <Badge
                                          className={`text-xs ${
                                            order.status === "delivered"
                                              ? "bg-green-100 text-green-800"
                                              : order.status === "cancelled"
                                                ? "bg-red-100 text-red-800"
                                                : "bg-blue-100 text-blue-800"
                                          }`}
                                        >
                                          {order.status}
                                        </Badge>
                                      </div>
                                    </div>
                                  ))}
                                {getCustomerOrders(customer.id).length === 0 && (
                                  <p className="text-gray-500 text-center py-4">No orders found</p>
                                )}
                              </div>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                )
              })}

              {filteredCustomers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                    No customers found. Try adjusting your search criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
