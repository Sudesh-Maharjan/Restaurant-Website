import RestaurantLanding from "../restaurant-landing"

export default function Page() {
  return <RestaurantLanding />
}
