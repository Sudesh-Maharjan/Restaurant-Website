"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "../contexts/cart-context"
import { useRestaurant } from "../contexts/restaurant-context"
import Image from "next/image"
import { Plus } from "lucide-react"

interface MenuItemProps {
  id: string
  name: string
  price: number
  description: string
  image: string
  badge?: string
  badgeColor?: string
}

export function MenuItemCard({
  id,
  name,
  price,
  description,
  image,
  badge,
  badgeColor = "bg-orange-600",
}: MenuItemProps) {
  const { dispatch } = useCart()
  const { state: restaurantState } = useRestaurant()

  // Check if product is available in restaurant state
  const product = restaurantState.products.find((p) => p.id === id)
  const isAvailable = product?.available ?? true

  const addToCart = () => {
    if (!isAvailable) return

    dispatch({
      type: "ADD_ITEM",
      payload: { id, name, price, description, image },
    })
  }

  return (
    <Card className={`overflow-hidden hover:shadow-lg transition-shadow group ${!isAvailable ? "opacity-60" : ""}`}>
      <div className="relative h-48">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {badge && <Badge className={`absolute top-4 left-4 ${badgeColor}`}>{badge}</Badge>}
        {!isAvailable && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <Badge className="bg-red-600">Unavailable</Badge>
          </div>
        )}
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="flex justify-between items-start">
          <span className="text-lg">{name}</span>
          <span className="text-orange-600 font-bold text-lg">${price}</span>
        </CardTitle>
        <CardDescription className="text-sm leading-relaxed">{description}</CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <Button
          onClick={addToCart}
          disabled={!isAvailable}
          className="w-full bg-orange-600 hover:bg-orange-700 group disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
          {isAvailable ? "Add to Cart" : "Unavailable"}
        </Button>
      </CardContent>
    </Card>
  )
}
